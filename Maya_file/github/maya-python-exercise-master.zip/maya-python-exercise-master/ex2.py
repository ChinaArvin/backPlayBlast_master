# Write a script that will move the selected object / objects 1.5 units up (in Y)
# (and keep moving it everytime it gets executed)

cmds.move(0, 1.5, 0, relative= True)