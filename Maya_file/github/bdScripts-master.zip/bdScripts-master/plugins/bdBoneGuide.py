import maya.api.OpenMaya as om
import maya.api.OpenMayaUI as omui
import pymel.core as pm

def maya_useNewApi():
    pass

class boneGuide(omui.MPxLocatorNode):
    id = om.MTypeId()