# bdScripts

- My name is Bogdan, I am technical animator, here are a bunch of scripts i have for Maya.
