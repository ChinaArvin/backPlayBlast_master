# ------- Global blueprint suffixes ------
BPGRP = 'bp_grp'
BPGUIDESGRP = 'guides_grp'
BPCTRL = 'trs'
BPGUIDE = 'guide'
# ------------------------------


# ------- Global rig suffixes ------
BNDJNT = 'BND'
FKJNT = 'FK'
IKJNT = 'IK'
DRVJNT = 'DRV'
CTRL = 'ctrl'
CTRLGRP = 'ctrl_grp'
# ------------------------------


# ------- Global character suffixes ------
CHAR = 'CHAR'
CHBPGRP = 'blueprints_grp'
CHCTRL = 'trs'
CHARROOT = 'root'
# ------------------------------
